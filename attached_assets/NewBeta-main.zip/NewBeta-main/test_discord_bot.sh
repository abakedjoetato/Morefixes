#!/bin/bash
# Script to run the Discord bot for testing
cd "$(dirname "$0")"
python3 run_discord_bot.py