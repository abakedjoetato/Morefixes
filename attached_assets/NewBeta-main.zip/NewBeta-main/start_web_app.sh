#!/bin/bash
# Web Application Starter Script for Tower of Temptation
# This script starts only the web application component, optimized for production environments

# Execute the main workflow script with the web-only flag
./start_workflow.sh --web-only