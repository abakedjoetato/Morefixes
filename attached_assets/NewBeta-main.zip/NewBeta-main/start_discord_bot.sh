#!/bin/bash
# Discord Bot Starter Script for Tower of Temptation
# This script starts only the Discord bot component, optimized for production environments

# Execute the main workflow script with the bot-only flag
./start_workflow.sh --bot-only